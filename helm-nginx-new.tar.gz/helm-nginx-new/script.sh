#!/bin/bash
echo "script-one.sh"
date
sleep 1
max_retry=10
retry_in_seconds=10
RUNTIME_FILE='/srv/runtime/runtimed_readiness'
if [ "${ENVIRONMENT}" != 'local' ]; then
n=0
until [ ${n} -ge ${max_retry} ]
do
    if [ ! -f "${RUNTIME_FILE}" ] ; then
    echo "WARN: runtimed is not ready yet. Retrying in ${retry_in_seconds} seconds."
    sleep ${retry_in_seconds}
    n=$((n+1))
    else
    echo "file ${RUNTIME_FILE} found."
    break
    fi
done
if [ ! -f "${RUNTIME_FILE}" ] ; then
    echo "ERROR: runtimed is not ready after ${max_retry} attempts. Giving up..."
    exit 1
fi
fi